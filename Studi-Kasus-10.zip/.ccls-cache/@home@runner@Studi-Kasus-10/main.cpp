#include <iostream>
#include "Input.h"
#include "Proses.h"
#include "Output.h"
int main() {
  sk10 x;
  x.input();
  x.proses();
  x.output();
  return 0;
}