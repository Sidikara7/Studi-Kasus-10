class sk10{
  public:
    void input();
    void proses();
    void output();
  private:
    int n;
    int *nim;
    int nimM[5];
    string *nama;
    string namaMhs[5];  
};