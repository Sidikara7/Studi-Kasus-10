using namespace std;
#include "Class.h"
void sk10::input(){
    cout << "======================================="<<endl;
    cout << "\t\t  Final Lomba Parmatika"<<endl;
    cout << "======================================="<<endl;
    for (int i=0; i<5; i++){
      cout << "Masukkan NIM  Finalis ke- "<<i+1<<"  :  ";
      cin >> nmq[i];
      cout << "Masukkan Nama Finalis ke- "<<i+1<<"  :  ";
      cin >> nmh[i];
      cout<<endl;
    }
  }