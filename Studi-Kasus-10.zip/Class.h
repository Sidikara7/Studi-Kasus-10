class sk10{
  public:
    void input();
    void proses();
    void output();
  private:
    int n;
    int *nim;
    int nmq[5];
    string *nama;
    string nmh[5];  
};